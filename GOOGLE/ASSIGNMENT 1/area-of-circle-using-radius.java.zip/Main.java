import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int r;
		 r = scan.nextInt();
		 double area;
		 double pi = 3.14;
		 area =  pi * r * r;
		 System.out.println("The area of the circle is "+(int)area);
	}
}

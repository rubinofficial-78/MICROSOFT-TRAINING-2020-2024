import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int a = scan.nextInt();
		double b = scan.nextDouble();
		double sum = (double)a + b;
		System.out.println("The sum value is "+sum);
	}
}
